package com.employeeDirectory.employee.adapters;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.employeeDirectory.employee.dao.Employee;

@Repository
public interface EmployeeAdapter extends CrudRepository<Employee, Integer> {
}
