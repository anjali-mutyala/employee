package com.employeeDirectory.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeDirectory.employee.adapters.EmployeeAdapter;
import com.employeeDirectory.employee.dao.Employee;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeAdapter employeeAdapter;
	public List<Employee> getAllEmployees() {
		return (List<Employee>) employeeAdapter.findAll();
	}
	public Employee addEmployee(Employee employee) {
		return employeeAdapter.save(employee);
	}
	public Optional<Employee> getEmployee(int id) {
		return employeeAdapter.findById(id);
	}
	public void deleteEmployee(int id) {
		employeeAdapter.deleteById(id);
	}
	public Object editEmployee(int id, Employee employee) {
		if(!employeeAdapter.findById(id).isPresent()) return "No Employee found";
		else {
			employee.setEmployeeID(id);
			return employeeAdapter.save(employee);
		}
	}

}
