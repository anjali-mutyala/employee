package com.employeeDirectory.employee.dao;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Employee {
	@Id
	@GeneratedValue
	private int employeeID;
	private String name;
	private String role;
//	@OneToMany(cascade = CascadeType.ALL, mappedBy="skill")
//	private List<Skill> skills = new ArrayList<>();
	
	public Employee() {}
	public Employee(int employeeID, String name, String role) {
		this.employeeID=employeeID;
		this.name=name;
		this.role=role;
	}
	public int getEmployeeID() {
		return employeeID;
	}
	public String getName() {
		return name;
	}
	public String getRole() {
		return role;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
//	public List<Skill> getSkills() {
//		return skills;
//	}
//	public void setSkills(List<Skill> skills) {
//		this.skills = skills;
//	}
	public void setName(String name) {
		this.name = name;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
}
