package com.employeeDirectory.employee.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Skill {

//	@Id
//	@GeneratedValue
//	private int skillId;
//	private int experience;
//	private String summary;
//	@ManyToOne
//	@JoinColumn(name = "employeeID")
//	private int employeeId;
//	public int getSkillId() {
//		return skillId;
//	}
//	public int getExperience() {
//		return experience;
//	}
//	public String getSummary() {
//		return summary;
//	}
//	public void setSkillId(int skillId) {
//		this.skillId = skillId;
//	}
//	public void setExperience(int experience) {
//		this.experience = experience;
//	}
//	public void setSummary(String summary) {
//		this.summary = summary;
//	}
}
